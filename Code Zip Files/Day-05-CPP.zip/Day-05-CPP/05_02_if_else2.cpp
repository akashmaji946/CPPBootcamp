
#include <iostream>
using namespace std;

//  main(void)
// void => nothing  => keyword
signed main(void){

    bool raining = true;
    bool healthy = true;
    bool mom_permit = true;

    if(!raining && healthy && mom_permit){     // ! => not 
        cout << "I am going to my friend house";
    }else{
        cout << "I am not going";
    }



    //

    // if(condition);   // mera if yhi khtm ho gya
    // if(......){
    //     /////
    //     ////
    //     ////
    //     ////
    // };


    return 1234;

}