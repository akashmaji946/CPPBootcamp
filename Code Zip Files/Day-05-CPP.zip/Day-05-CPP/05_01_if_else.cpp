

#include <iostream>
using namespace std;

int main(){
    // if else

    int num;
    cout << "Enter a number ";
    cin >> num;


    // cin    >>
    // cout   <<

    // even or odd => 28 => even

    // num % 2 == 0  (%   remainder)

    if(num % 2 == 0){
        cout << num << " num is even\n";
    }else{
        cout << num << " num is odd\n";
    }

    
    return 0;
}
