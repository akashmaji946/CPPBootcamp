

#include <iostream>
using namespace std;

int main(){

    // if condition

    int a = 10;
    

    // ==     equality
    if(a == 5){
      cout << "a is 10" << endl;
      /////
      /////
      /////
    }

    cout << " I am outside if\n";

    return 0;
}
