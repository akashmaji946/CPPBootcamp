#include <iostream>
using namespace std;
int main() {

	// Program 3

	// 1.....10

	// initialization
	int i = 1;

	while(i <= 12){   //condition
		cout << i << endl;

		//updation
		i++;
	}
  

  return 0;
}