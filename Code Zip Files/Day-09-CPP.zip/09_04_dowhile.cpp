#include <iostream>
using namespace std;
int main() {

	// Program 4

	// 1......10

	int i = -1; //initialization

    // infinite loop
	//yha se start ho rha hai
	do{
		//body
        cout << i << endl;

		//updation
	    i++;

	}while(i < 0);  

	
  

  return 0;
}