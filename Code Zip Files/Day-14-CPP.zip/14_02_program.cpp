#include <stdio.h>
// using namespace std;

// printf()  
// scanf()

int main(){

	printf("Hello World\n");
	int n;
	scanf("%d", &n);
	printf("%d\n", n);


	return 0;
}


// c++ => c ka baap haii

// C++ => C
