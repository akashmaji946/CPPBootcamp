#include <iostream>
using namespace std;

int main(){
	cout << "this is day 2\n";

	// int => 2, 4, 6, 9, -12, ....

	int age = 50;
	cout << age + 10 << "\n";

	// double => 123.98
	double percent = 87.98;  // bty default
	cout << percent << endl;

	// float
	float salary = 129.8F;    // F  => float
	cout << salary << endl;

	// char  =>   A    B    C    D   (letters)

	char ch = 'A';   // characters => single quotes
	ch = '+';
	cout << ch << endl;

	string name = "manoj";
	cout << name << endl;

	age = age + 10;   // 50+ 10 => 60   .... age=60
	cout << age << endl;   // value changed


	name = name + " singh";   // manoj + singh  => manojsingh
	cout << name << endl;






	return 0;
}
