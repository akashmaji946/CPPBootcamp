
#include <iostream>
using namespace std;

int main(){

	//user input
	long int age;  // no value   => garbage value

	// input => cin  (console input)
	cout << "Enter Your Age: ";
	cin >> age;
	cout << "Your age is: ";
	cout << age << endl;

	// name
	string name;
	cout << "Enter Your Name: ";
	cin >> name;    /// Akash   "Akash"
	cout << "Your name is: ";
	cout << name << endl;





	return 0;
}