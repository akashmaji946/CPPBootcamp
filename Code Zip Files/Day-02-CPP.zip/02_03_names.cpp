
#include <iostream>
using namespace std;

int main(){

	// names

	int no_of_oranges = 10;   // underscore
	string myName = "Akash";
	
	// 90000.0;
	// "900000"

	//myname  myName
	// myHouseAddress
	// yourFavouriteBook    => camel casing


	return 0;
}