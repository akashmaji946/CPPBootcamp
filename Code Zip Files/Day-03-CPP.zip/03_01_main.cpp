
//we will write main in other way

#include <iostream>
using namespace std;


int main(){
   
    cout << "Welcome to Day-3 Part 1" << endl;

	// Kwywords => reserved in C++
	// int float double
	// switch

	// int 1NAME = 10;  // number se start nhi krna hai

	// CONSTANTS
	// const keyword

	// PI (uppercase)
	const double pi = 3.14;
	// gravity = 9.81 (OK but use uppercase)
	const double GRAVITY = 9.81;

	// 1 tab = 4 spaces

	cout << pi << "\t" << GRAVITY << endl;

	// constants can not be changed
   //	pi = 4.14; // error

	

	return 0;
}
