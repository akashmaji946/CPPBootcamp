#include <iostream>
using namespace std;

int main() {
  cout << "Hello World!\n";



  ///printf() => printf

  printf("%s  %d   %c \n", "Hello World", 10, 'A');


  // scanf()

  int a;
  float b;
  char c;

  scanf("%d %f %c", &a, &b, &c);

  // %f => 6 decimal places
  printf("%d\n%f\n%c\nHello World", a, b, c);











}