
#include <iostream>
#include <iomanip>
using namespace std;


int main(){

	//  integer exp

	// float exp

	float f = 10 + 1.5;
	cout << f << endl;

	// constannt expr
   int x = 100;
	int v = 10 + 10 * x / x;
	cout << v << endl;

	// boolean
	bool b = true && false;
	cout << boolalpha << b << endl; // manipulator


	// relational

	bool c = 2 < 5 && 5 > 6;
	cout << boolalpha << c << endl;

	cout << noboolalpha;

	// boolean + relational => true/false
	// if else    loops

	














	return 0;
}