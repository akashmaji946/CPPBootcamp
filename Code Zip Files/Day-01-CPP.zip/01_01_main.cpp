#include <iostream>
// library => functions + variables

// object => cout
using namespace std;
// basic input output => cin     cout

// main is the starting point
// int => integer    0, 1, 2, ..........(integer)
int main() {


  // standard namespace
  //   \n    => new line
  //   endl   => end line
  cout << "Hello CPP Buddies" << endl;   
  return 0;
  // OS 
}